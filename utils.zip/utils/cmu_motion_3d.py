from torch.utils.data import Dataset
import numpy as np
import os
from utils import data_utils
from scipy.ndimage import gaussian_filter1d

# def smooth_data(data, sigma=1):
#     """
#     高斯平滑处理数据
#     :param data: 输入数据，形状为 (N, T, M)
#     :param sigma: 高斯核的标准差
#     :return: 平滑后的数据，形状为 (N, T, M)
#     """
#     # 对时间轴 (axis=1) 应用高斯平滑
#     smoothed_data = gaussian_filter1d(data, sigma=sigma, axis=1)
#     return smoothed_data

def smooth_data(data, window_size=3):
    """
    平滑处理数据
    :param data: 输入数据，形状为 (N, T, M)
    :param window_size: 平滑窗口大小
    :return: 平滑后的数据，形状为 (N, T, M)
    """
    smoothed_data = np.zeros_like(data)
    for i in range(data.shape[1]):
        start = max(0, i - window_size + 1)
        smoothed_data[:, i, :] = np.mean(data[:, start:i+1, :], axis=1)
    return smoothed_data

def get_stream(data, view):
    N, T, M = data.shape
    if view == 'joint':
        pass
    elif view == 'motion':
        motion = np.zeros_like(data)
        motion[:, :-1, :] = data[:, 1:, :] - data[:, :-1, :]
        motion[:, -1, :] = motion[:, -2, :]
        data = motion
    elif view == 'acceleration':
        accel = np.zeros_like(data)
        accel[:, 1:-1, :] = data[:, 2:, :] - data[:, 1:-1, :]
        accel[:, 0, :] = accel[:, 1, :]
        accel[:, -1, :] = 0        
        data = accel
    return data

class CMU_Motion3D(Dataset):

    def __init__(self, path_to_data, actions, input_n=10, output_n=10, split=0, data_mean=0, data_std=0, dim_used=0,
                 dct_n=15, window_size=3,sigma=1):

        self.path_to_data = path_to_data
        self.split = split
        self.sigma = sigma
        self.window_size = window_size
        actions = data_utils.define_actions_cmu(actions)
        # actions = ['walking']#test用
        if split == 0:
            path_to_data = os.path.join(path_to_data, 'train')
            is_test = False
        else:
            path_to_data = os.path.join(path_to_data, 'test')
            is_test = True
        all_seqs, dim_ignore, dim_use, data_mean, data_std = data_utils.load_data_cmu_3d(path_to_data, actions,
                                                                                         input_n, output_n,
                                                                                         data_std=data_std,
                                                                                         data_mean=data_mean,
                                                                                         is_test=is_test)
        if not is_test:
            dim_used = dim_use

        self.all_seqs = all_seqs
        self.dim_used = dim_used
        all_seqs = all_seqs[:, :, dim_used]

        pad_idx = np.repeat([input_n - 1], output_n)
        i_idx = np.append(np.arange(0, input_n), pad_idx)
        repeated_seqs = all_seqs[:, i_idx, :]

        # 存储这些重复的帧以计算它们的均值
        last_frames = repeated_seqs[:, -output_n:, :]

        # 计算这些重复帧的均值并将其重复output_n次
        last_frames_mean = np.mean(last_frames, axis=1, keepdims=True)
        pad_seq = np.tile(last_frames_mean, (1, output_n, 1))

        # 将这些均值帧拼接到输入序列中
        input_seqs = np.concatenate((all_seqs[:, :input_n, :], pad_seq), axis=1)
        accel_data = get_stream(all_seqs, 'acceleration')
        accel_data = np.concatenate((accel_data[:, :input_n, :], pad_seq), axis=1)
        accel_data = accel_data[:, i_idx, :]

        t_joint = accel_data  # N,T,VC
        s_joint = accel_data.transpose(0, 2, 1)  # N,VC,T
        
        self.input = smooth_data(input_seqs, self.window_size)
        self.input_t = smooth_data(t_joint, self.window_size)
        self.input_s = smooth_data(s_joint.transpose(0, 2, 1), self.window_size).transpose(0, 2, 1)

        self.data_mean = data_mean
        self.data_std = data_std

    def __len__(self):
        return np.shape(self.input)[0]

    def __getitem__(self, item):
        return self.input[item], self.input_t[item], self.input_s[item], self.all_seqs[item]
