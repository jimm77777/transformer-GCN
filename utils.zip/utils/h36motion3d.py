from torch.utils.data import Dataset
import numpy as np
from h5py import File
import scipy.io as sio
from utils import data_utils


def smooth_data(data, window_size=3):
    """
    平滑处理数据
    :param data: 输入数据，形状为 (N, T, M)
    :param window_size: 平滑窗口大小
    :return: 平滑后的数据，形状为 (N, T, M)
    """
    smoothed_data = np.zeros_like(data)
    for i in range(data.shape[1]):
        start = max(0, i - window_size + 1)
        smoothed_data[:, i, :] = np.mean(data[:, start:i+1, :], axis=1)
    return smoothed_data

def get_stream(data, view):
    N, T, M = data.shape
    if view == 'joint':
        pass
    elif view == 'motion':
        motion = np.zeros_like(data)
        motion[:, :-1, :] = data[:, 1:, :] - data[:, :-1, :]
        motion[:, -1, :] = motion[:, -2, :]
        data = motion
    elif view == 'acceleration':
        accel = np.zeros_like(data)
        accel[:, 1:-1, :] = data[:, 2:, :] - data[:, 1:-1, :]  # 计算加速度
        accel[:, 0, :] = accel[:, 1, :]  # 边界处理
        accel[:, -1, :] = accel[:, -2, :]
        data = accel
    return data

class H36motion3D(Dataset):

    def __init__(self, path_to_data, actions, input_n=20, output_n=10, split=0, sample_rate=2,window_size=3):
        """
        :param path_to_data:
        :param actions:
        :param input_n:
        :param output_n:
        :param dct_used:
        :param split: 0 train, 1 testing, 2 validation
        :param sample_rate:
        """
        self.path_to_data = path_to_data
        self.split = split
        self.window_size = window_size
        subs = np.array([[1, 6, 7, 8, 9], [5], [11]])
        acts = data_utils.define_actions(actions)

        # subs = np.array([[1], [5], [11]])
        # acts = ['walking']

        subjs = subs[split]
        all_seqs, dim_ignore, dim_used = data_utils.load_data_3d(path_to_data, subjs, acts, sample_rate, input_n + output_n)

        self.all_seqs = all_seqs
        self.dim_used = dim_used
        all_seqs = all_seqs[:, :, dim_used] # 选择使用的维度

        pad_idx = np.repeat([input_n - 1], output_n)
        i_idx = np.append(np.arange(0, input_n), pad_idx)
        repeated_seqs = all_seqs[:, i_idx, :]

        # 存储这些重复的帧以计算它们的均值
        last_frames = repeated_seqs[:, -output_n:, :]

        # 计算这些重复帧的均值并将其重复output_n次
        last_frames_mean = np.mean(last_frames, axis=1, keepdims=True)
        pad_seq = np.tile(last_frames_mean, (1, output_n, 1))

        # 将这些均值帧拼接到输入序列中
        input_seqs = np.concatenate((all_seqs[:, :input_n, :], pad_seq), axis=1)

        accel_data = get_stream(all_seqs, 'acceleration')
        accel_data = np.concatenate((accel_data[:, :input_n, :], pad_seq), axis=1)
        accel_data = accel_data[:, i_idx, :]

        t_joint = accel_data  # N,T,VC
        s_joint = accel_data.transpose(0, 2, 1)  # N,VC,T
        
        self.input = smooth_data(input_seqs, self.window_size)
        self.input_t = smooth_data(t_joint, self.window_size)
        self.input_s = smooth_data(s_joint.transpose(0, 2, 1), self.window_size).transpose(0, 2, 1)       

    def __len__(self):
        return np.shape(self.input_t)[0]

    def __getitem__(self, item):
        return self.input[item], self.input_t[item], self.input_s[item], self.all_seqs[item]
