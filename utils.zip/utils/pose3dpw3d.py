import pickle as pkl
from os import walk
from torch.utils.data import Dataset
import numpy as np
from utils import data_utils
from scipy.ndimage import gaussian_filter1d
from scipy.signal import savgol_filter

# def savgol_smooth_data(data, window_length=5, polyorder=2):
#     """
#     Savitzky-Golay 平滑处理数据
#     :param data: 输入数据，形状为 (N, T, M)
#     :param window_length: 滑动窗口长度（奇数）
#     :param polyorder: 多项式拟合阶数
#     :return: 平滑后的数据，形状为 (N, T, M)
#     """
#     smoothed_data = savgol_filter(data, n_, polyorder=polyorder, axis=1)
#     return smoothed_data

# def smooth_data(data, sigma=1):
#     """
#     高斯平滑处理数据
#     :param data: 输入数据，形状为 (N, T, M)
#     :param sigma: 高斯核的标准差
#     :return: 平滑后的数据，形状为 (N, T, M)
#     """
#     # 对时间轴 (axis=1) 应用高斯平滑
#     smoothed_data = gaussian_filter1d(data, sigma=sigma, axis=1)
#     return smoothed_data
def smooth_data(data, window_size=3):
    """
    平滑处理数据
    :param data: 输入数据，形状为 (N, T, M)
    :param window_size: 平滑窗口大小
    :return: 平滑后的数据，形状为 (N, T, M)
    """
    smoothed_data = np.zeros_like(data)
    for i in range(data.shape[1]):
        start = max(0, i - window_size + 1)
        smoothed_data[:, i, :] = np.mean(data[:, start:i+1, :], axis=1)
    return smoothed_data


def get_stream(data, view):
    N, T, M = data.shape
    if view == 'joint':
        pass
    elif view == 'motion':
        motion = np.zeros_like(data)
        motion[:, :-1, :] = data[:, 1:, :] - data[:, :-1, :]
        motion[:, -1, :] = motion[:, -2, :]
        data = motion
    elif view == 'acceleration':
        accel = np.zeros_like(data)
        accel[:, 1:-1, :] = data[:, 2:, :] - data[:, 1:-1, :]  # 计算加速度
        accel[:, 0, :] = accel[:, 1, :]  # 边界处理
        accel[:, -1, :] = accel[:, -2, :]
        data = accel
    return data

class Pose3dPW3D(Dataset):

    def __init__(self, path_to_data, input_n=20, output_n=10, dct_n=15, split=0, window_size=3,sigma=1,polyorder=2,use_mean_padding=False):
        """

        :param path_to_data:
        :param input_n:
        :param output_n:
        :param dct_n:
        :param split:
        :param window_size: 平滑窗口大小
        """
        self.path_to_data = path_to_data
        self.split = split
        self.dct_n = dct_n
        self.use_mean_padding = use_mean_padding
        # self.window = window_size
        # self.polyorder = polyorder
        self.window_size = window_size #滑窗
        # self.sigma = sigma #高斯
        # since baselines (http://arxiv.org/abs/1805.00655.pdf and https://arxiv.org/pdf/1705.02445.pdf)
        # use observed 50 frames but our method use 10 past frames in order to make sure all methods are evaluated
        # on same sequences, we first crop the sequence with 50 past frames and then use the last 10 frame as input
        if split == 1:
            their_input_n = 50
        else:
            their_input_n = input_n
        seq_len = their_input_n + output_n

        if split == 0:
            self.data_path = path_to_data + '/train/'
        elif split == 1:
            self.data_path = path_to_data + '/test/'
        elif split == 2:
            self.data_path = path_to_data + '/validation/'
        all_seqs = []
        files = []
        for (dirpath, dirnames, filenames) in walk(self.data_path):
            files.extend(filenames)
        for f in files:
            with open(self.data_path + f, 'rb') as f:
                data = pkl.load(f, encoding='latin1')
                joint_pos = data['jointPositions']
                for i in range(len(joint_pos)):
                    seqs = joint_pos[i]
                    seqs = seqs - seqs[:, 0:3].repeat(24, axis=0).reshape(-1, 72)
                    n_frames = seqs.shape[0]
                    fs = np.arange(0, n_frames - seq_len + 1)
                    fs_sel = fs
                    for j in np.arange(seq_len - 1):
                        fs_sel = np.vstack((fs_sel, fs + j + 1))
                    fs_sel = fs_sel.transpose()
                    seq_sel = seqs[fs_sel, :]
                    if len(all_seqs) == 0:
                        all_seqs = seq_sel
                    else:
                        all_seqs = np.concatenate((all_seqs, seq_sel), axis=0)

        self.all_seqs = all_seqs[:, (their_input_n - input_n):, :]
        self.dim_used = np.array(range(3, all_seqs.shape[2]))
        all_seqs = all_seqs[:, (their_input_n - input_n):, 3:]
        if self.use_mean_padding:
            pad_idx = np.repeat([input_n - 1], output_n)
            i_idx = np.append(np.arange(0, input_n), pad_idx)
            repeated_seqs = all_seqs[:, i_idx, :]

            # 存储这些重复的帧以计算它们的均值
            last_frames = repeated_seqs[:, -output_n:, :]

            # 计算这些重复帧的均值并将其重复output_n次
            last_frames_mean = np.mean(last_frames, axis=1, keepdims=True)
            pad_seq = np.tile(last_frames_mean, (1, output_n, 1))

            # 将这些均值帧拼接到输入序列中
            input_seqs = np.concatenate((all_seqs[:, :input_n, :], pad_seq), axis=1)

            accel_data = get_stream(all_seqs, 'acceleration')
            accel_data = np.concatenate((accel_data[:, :input_n, :], pad_seq), axis=1)
            accel_data = accel_data[:, i_idx, :]
        else:
            pad_idx = np.repeat([input_n - 1], output_n)
            i_idx = np.append(np.arange(0, input_n), pad_idx)
            input_seqs= all_seqs[:,i_idx,:]
            accel_data = get_stream(all_seqs,'acceleration')
            accel_data = accel_data[:,i_idx,:]

        t_joint = accel_data  # N,T,VC
        s_joint = accel_data.transpose(0, 2, 1)  # N,VC,T
        
        self.input = smooth_data(input_seqs, self.window_size)
        self.input_t = smooth_data(t_joint, self.window_size)
        self.input_s = smooth_data(s_joint.transpose(0, 2, 1), self.window_size).transpose(0, 2, 1)

    def __len__(self):
        return np.shape(self.input)[0]

    def __getitem__(self, item):
        return self.input[item]*1000, self.input_t[item]*1000, self.input_s[item]*1000, self.all_seqs[item]*1000